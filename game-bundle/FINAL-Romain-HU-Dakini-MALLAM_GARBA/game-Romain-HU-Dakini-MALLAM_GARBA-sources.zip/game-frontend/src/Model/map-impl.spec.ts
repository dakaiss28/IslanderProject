import { MapImpl } from './map-impl';

describe('MapImpl', () => {
  it('should create an instance', () => {
    expect(new MapImpl()).toBeTruthy();
  });
});
