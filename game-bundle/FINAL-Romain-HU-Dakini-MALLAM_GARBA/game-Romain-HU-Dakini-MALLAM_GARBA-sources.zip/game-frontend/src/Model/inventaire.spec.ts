import { Inventaire } from './inventaire';

describe('Inventaire', () => {
  it('should create an instance', () => {
    expect(new Inventaire()).toBeTruthy();
  });
});
