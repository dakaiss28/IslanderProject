package game.model;

/**
 * the tree type of Tiles possible on the Map
 */
public enum Type {
    TREE, WATER, GRASS
}
