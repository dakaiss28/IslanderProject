package game.Commands;

public interface Undoable {
    void undo();
    void redo();

}
