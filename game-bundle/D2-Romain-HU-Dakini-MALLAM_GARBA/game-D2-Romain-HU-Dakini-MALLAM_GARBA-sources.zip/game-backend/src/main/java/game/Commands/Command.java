package game.Commands;

public interface Command {
    void execute();
}
